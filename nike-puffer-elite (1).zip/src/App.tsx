/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, ShoppingBag, Plus, Minus, Search, User } from 'lucide-react';

const COLORS = [
  { name: 'Orange', bg: '#FF6B00', jacket: 'https://i.postimg.cc/rz67pmGZ/Gemini-Generated-Image-u0nv4qu0nv4qu0nv-removebg-preview.png' },
  { name: 'Brown', bg: '#5D4037', jacket: 'https://i.postimg.cc/pr7RJRfJ/Gemini-Generated-Image-hqevm9hqevm9hqev-removebg-preview.png' },
  { name: 'Purple', bg: '#4B0082', jacket: 'https://i.postimg.cc/Zq7b58WL/Gemini-Generated-Image-3ca0iz3ca0iz3ca0-removebg-preview.png' },
];

// Note: Finding a perfect transparent 3D jacket is hard with external URLs. 
// I will use high-quality product shots and apply a mask or just use them as focal points.
// For the "color change" effect, I'll use CSS filters or different images if available.
// Actually, I'll use a single high-quality jacket image and use CSS mix-blend-mode or filters to simulate color changes if possible, 
// OR I'll use different images that represent the colors.

const PRODUCT_IMAGES = {
  Orange: "https://i.postimg.cc/rz67pmGZ/Gemini-Generated-Image-u0nv4qu0nv4qu0nv-removebg-preview.png",
  Brown: "https://i.postimg.cc/pr7RJRfJ/Gemini-Generated-Image-hqevm9hqevm9hqev-removebg-preview.png",
  Purple: "https://i.postimg.cc/Zq7b58WL/Gemini-Generated-Image-3ca0iz3ca0iz3ca0-removebg-preview.png",
};

export default function App() {
  const [currentColorIndex, setCurrentColorIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [activeWeight, setActiveWeight] = useState(750);

  const currentColor = COLORS[currentColorIndex];

  const nextColor = () => {
    setCurrentColorIndex((prev) => (prev + 1) % COLORS.length);
  };

  return (
    <div 
      className="min-h-screen w-full overflow-hidden font-sans transition-colors duration-1000 ease-in-out relative"
      style={{ backgroundColor: currentColor.bg }}
    >
      {/* Subtle Nike Swoosh Watermark */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-10 select-none overflow-hidden">
        <svg 
          viewBox="0 0 100 100" 
          className="w-[150%] h-[150%] -rotate-12 fill-white"
        >
          <path d="M20,50 C40,40 70,40 90,60 C70,55 40,55 10,80 C15,70 18,60 20,50 Z" />
        </svg>
      </div>

      {/* Navigation */}
      <nav className="relative z-20 flex items-center justify-between px-8 py-6 text-white">
        <div className="flex items-center gap-12">
          <div className="text-2xl font-black tracking-tighter italic">NIKE</div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium uppercase tracking-widest opacity-80">
            <a href="#" className="hover:opacity-100 transition-opacity">Menu</a>
            <a href="#" className="hover:opacity-100 transition-opacity">About</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Shop</a>
            <a href="#" className="hover:opacity-100 transition-opacity">Contact</a>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <Search size={20} className="cursor-pointer opacity-80 hover:opacity-100" />
          <User size={20} className="cursor-pointer opacity-80 hover:opacity-100" />
          <ShoppingBag size={20} className="cursor-pointer opacity-80 hover:opacity-100" />
        </div>
      </nav>

      {/* Main Content */}
      <main className="relative z-10 grid grid-cols-1 lg:grid-cols-12 h-[calc(100vh-88px)] items-center px-8 lg:px-16 pb-12">
        
        {/* Left Content */}
        <div className="lg:col-span-4 text-white space-y-6 relative z-20">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <h1 className="text-6xl lg:text-8xl font-black leading-[0.9] tracking-tighter uppercase drop-shadow-lg">
              Wear your <br /> Style with <br /> Comfort
            </h1>
            <p className="mt-8 text-lg opacity-90 max-w-sm font-light leading-relaxed drop-shadow-md">
              Experience the ultimate blend of warmth and street style. Our latest puffer collection is engineered for the bold, the active, and the fashion-forward.
            </p>
          </motion.div>
        </div>

        {/* Center Product Visual (Larger and Behind) */}
        <div className="absolute inset-0 flex items-center justify-center z-0 pointer-events-none">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentColor.name}
              initial={{ opacity: 0, scale: 0.5 }}
              animate={{ opacity: 1, scale: 1.5 }}
              exit={{ opacity: 0, scale: 0.5 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
              style={{ perspective: 1000 }}
              className="relative w-[80vh] aspect-square flex items-center justify-center pointer-events-auto cursor-pointer"
              onClick={nextColor}
            >
              {/* Product Glow */}
              <div 
                className="absolute inset-0 blur-[150px] opacity-40 rounded-full"
                style={{ backgroundColor: 'white' }}
              />
              
              {/* The Jacket Image (Static) */}
              <motion.img 
                src={currentColor.jacket} 
                alt={`Nike Puffer - ${currentColor.name}`}
                className="w-full h-full object-contain drop-shadow-[0_50px_50px_rgba(0,0,0,0.5)]"
                referrerPolicy="no-referrer"
              />
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Spacer for the grid center */}
        <div className="lg:col-span-4 h-full pointer-events-none" />

        {/* Right Content / Controls */}
        <div className="lg:col-span-4 flex flex-col items-end justify-between h-full py-12 relative z-20">
          
          {/* Weight Selectors (Top Right) */}
          <div className="flex flex-col items-end gap-4">
            <span className="text-[10px] uppercase tracking-[0.3em] text-white opacity-50 font-bold">Select Weight</span>
            <div className="flex gap-3">
              {[750, 500, 250].map((weight) => (
                <button
                  key={weight}
                  onClick={() => setActiveWeight(weight)}
                  className={`w-14 h-14 rounded-full border flex items-center justify-center text-sm font-bold transition-all duration-300 ${
                    activeWeight === weight 
                      ? 'bg-white text-black border-white scale-110' 
                      : 'bg-transparent text-white border-white/30 hover:border-white'
                  }`}
                >
                  {weight}
                </button>
              ))}
            </div>
          </div>

          {/* Add to Cart & Quantity (Bottom Right) */}
          <div className="flex items-center gap-6">
            <div className="flex items-center bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-4 py-2 text-white">
              <button 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="p-1 hover:bg-white/20 rounded-full transition-colors"
              >
                <Minus size={16} />
              </button>
              <span className="w-12 text-center font-bold text-lg">{quantity}</span>
              <button 
                onClick={() => setQuantity(quantity + 1)}
                className="p-1 hover:bg-white/20 rounded-full transition-colors"
              >
                <Plus size={16} />
              </button>
            </div>
            
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-white text-black px-10 py-5 rounded-full font-black uppercase tracking-widest text-sm shadow-2xl hover:bg-opacity-90 transition-all"
            >
              Add to Cart
            </motion.button>
          </div>
        </div>
      </main>

      {/* Pricing (Bottom Center) */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-white text-center"
        >
          <span className="text-[10px] uppercase tracking-[0.5em] opacity-50 block mb-2 font-bold">Premium Quality</span>
          <div className="text-7xl font-black tracking-tighter flex items-start justify-center">
            <span className="text-2xl mt-3 mr-1">$</span>
            99.50
          </div>
        </motion.div>
      </div>

      {/* Color Indicators (Bottom Left) */}
      <div className="absolute bottom-12 left-16 z-20 flex flex-col gap-3">
        <span className="text-[10px] uppercase tracking-[0.3em] text-white opacity-50 font-bold">Colors</span>
        <div className="flex gap-4">
          {COLORS.map((color, idx) => (
            <button
              key={color.name}
              onClick={() => setCurrentColorIndex(idx)}
              style={{ backgroundColor: color.bg }}
              className={`w-8 h-8 rounded-full transition-all duration-300 border-2 shadow-xl ${
                currentColorIndex === idx ? 'border-white scale-125' : 'border-white/20 hover:border-white/50'
              }`}
              title={color.name}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
